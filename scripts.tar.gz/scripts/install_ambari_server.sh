#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as non-root" 
   exit 1
fi

wget -nv http://dmmanager/ambari/centos7/2.x/updates/2.6.1.0/ambari.repo -O /etc/yum.repos.d/ambari.repo
yum update
yum install ambari-server postgresql-jdbc*

chmod 644 /usr/share/java/postgresql-jdbc.jar

sed -i 's/public-repo-1.hortonworks.com/dmmanager/g' /etc/ambari-server/conf/ambari.properties

ambari-server setup

psql -h dmmanager -U ambari -d ambari -W < /var/lib/ambari-server/resources/Ambari-DDL-Postgres-CREATE.sql

ambari-server start

wget http://dmmanager/ARTIFACTS/postgresql-42.2.1.jar

ambari-server setup --jdbc-db=postgres --jdbc-driver=postgresql-42.2.1.jar

rm -rf postgresql-42.2.1.jar

