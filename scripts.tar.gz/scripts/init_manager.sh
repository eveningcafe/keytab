#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as non-root" 
   exit 1
fi

#change it
LDAP_SEARCH_BASE="ou=Users,dc=sirc,dc=com"

echo "---------------------------------------------------"
yum install ntp ntpdate
systemctl stop ntpd && ntpdate dmclient
sed -i 's/^server/#server/g' /etc/ntp.conf
echo "server dmclient iburst" >> /etc/ntp.conf
systemctl enable ntpd && systemctl start ntpd

echo "---------------------------------------------------"
echo "Disable SELinux"
setenforce 0
sed -i 's/^SELINUX=.*/SELINUX=disabled/g' /etc/selinux/config

echo "---------------------------------------------------"
echo "Set umask=0022"
umask 0022 && echo umask 0022 >> /etc/profile

echo "---------------------------------------------------"
echo "Install & Configure SSSD"
yum install openssl-devel.x86_64 openldap-clients sssd

cat >/etc/sssd/sssd.conf <<EOL
[sssd]
config_file_version = 2
domains = default
services = nss, pam

[nss]
filter_groups = root
filter_users = root
reconnection_retries = 3

[pam]
reconnection_retries = 3
offline_credentials_expiration = 2
offline_failed_login_attempts = 3
offline_failed_login_delay = 5

[domain/default]
auth_provider = ldap
id_provider = ldap
min_id = 2000
ldap_tls_reqcert = never
ldap_uri = ldap://dmmanager:389
ldap_search_base = $LDAP_SEARCH_BASE
cache_credentials = True 
EOL

chmod 600 /etc/sssd/sssd.conf
systemctl enable sssd
systemctl start sssd
authconfig --disablesssdauth --update

echo "---------------------------------------------------"
echo "Setup UserGuides"
mkdir -p /home/docker/guides
mkdir -p /home/docker/guides/html
cd /home/docker/guides

cat >/home/docker/guides/docker-compose.yml <<EOL
version: '2'

services:
  nginx:
    image: nginx:1.13.8
    restart: always
    volumes:
      - ./html:/usr/share/nginx/html:ro
    ports:
      - "9981:80"
EOL

cat >/home/docker/guides/html/index.html <<EOL
<!DOCTYPE html>
<html lang="en-US">
<head>
<title>DataMining Security - User Guides</title>
<meta charset="utf-8">
</head>
<body>

<h1 id="datamining-security---user-guides">DataMining Security - User Guides</h1>
<h3 id="links-webui">1. Links WebUI</h3>
<table style="width:45%;" border="1">
<colgroup>
<col width="11%" />
<col width="11%" />
<col width="11%" />
<col width="11%" />
</colgroup>
<thead>
<tr class="header">
<th>#</th>
<th>Service</th>
<th>Link</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>1</td>
<td>User Guides</td>
<td><a href="/gateway/ui/guides/" class="uri">/gateway/ui/guides/</a></td>
<td>No Authentication <br> User Guides</td>
</tr>
<tr class="even">
<td>2</td>
<td>Ambari</td>
<td><a href="/gateway/ui/ambari/" class="uri">/gateway/ui/ambari/</a></td>
<td>Authentication using Ambari</td>
</tr>
<tr class="odd">
<td>3</td>
<td>Ranger</td>
<td><a href="/gateway/ui/ranger/" class="uri">/gateway/ui/ranger/</a></td>
<td>Authentication using Ranger</td>
</tr>
<tr class="even">
<td>4</td>
<td>Zeppelin</td>
<td><a href="/gateway/ui/zeppelin/" class="uri">/gateway/ui/zeppelin/</a></td>
<td>Authentication using Zeppelin</td>
</tr>
<tr class="odd">
<td>5</td>
<td>Spark History</td>
<td><a href="/gateway/ui/sparkhistory/" class="uri">/gateway/ui/sparkhistory/</a></td>
<td>No Authentication <br> Only show jobs after they complete is the history server</td>
</tr>
<tr class="even">
<td>6</td>
<td>Account Management</td>
<td><a href="/gateway/ui/accmgmt/" class="uri">/gateway/ui/accmgmt/</a></td>
<td>Administrator: User and group management <br> User: Change password</td>
</tr>
<tr class="odd">
<td>7</td>
<td>HDFS</td>
<td><a href="/gateway/default/hdfs/" class="uri">/gateway/default/hdfs/</a></td>
<td>HTTP Basic Authentication <br> Hadoop cluster healthy status and view HDFS filesystem</td>
</tr>
<tr class="even">
<td>8</td>
<td>YARN</td>
<td><a href="/gateway/default/yarn/" class="uri">/gateway/default/yarn/</a></td>
<td>HTTP Basic Authentication <br> View app, jobs</td>
</tr>
</tbody>
</table>
</body>
</html>
EOL

cd /home/docker/guides
docker-compose up -d
echo "Waitting 10 seconds ..."
sleep 10

echo "---------------------------------------------------"
echo "Trim logs"
cat >/etc/cron.daily/trim_logs <<EOL
#!/bin/bash
find /var/log/hadoop -mtime +7 | xargs --no-run-if-empty rm
find /var/log/knox -mtime +7 | xargs --no-run-if-empty rm
find /var/log/oozie -mtime +30 | xargs --no-run-if-empty rm
find /var/log/ranger -mtime +7 | xargs --no-run-if-empty rm
find /var/log/ambari-metrics-collector -mtime +7 | xargs --no-run-if-empty rm
find /var/log/hadoop/hdfs/hdfs-audit.log.* -mmin +1440 | xargs --no-run-if-empty rm
EOL
chmod +x /etc/cron.daily/trim_logs

