#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as non-root" 
   exit 1
fi

#change it
LDAP_SEARCH_BASE="ou=Users,dc=sirc,dc=com"
#NTP_EXTERNAL_SERVER="192.168.181.50"

echo "---------------------------------------------------"
echo "Backup yum.repo"
mkdir -p /root/yum.repo.bak
mv /etc/yum.repos.d/CentOS-*.repo /root/yum.repo.bak

echo "---------------------------------------------------"
echo "Setup Centos internal repository"
wget -nv http://dmmanager/centos7_os/CentOS-OS-Internal.repo -O /etc/yum.repos.d/CentOS-OS-Internal.repo
yum update
rm -rf /etc/yum.repos.d/CentOS-Base.repo 
rm -rf /etc/yum.repos.d/CentOS-CR.repo 
rm -rf /etc/yum.repos.d/CentOS-Debuginfo.repo 
rm -rf /etc/yum.repos.d/CentOS-fasttrack.repo 
rm -rf /etc/yum.repos.d/CentOS-Media.repo 
rm -rf /etc/yum.repos.d/CentOS-Sources.repo 
rm -rf /etc/yum.repos.d/CentOS-Vault.repo
yum update

echo "---------------------------------------------------"
echo "Disable firewalld:"
systemctl disable firewalld && service firewalld stop
echo "---------------------------------------------------"
yum install ntp ntpdate
systemctl stop ntpd
sed -i 's/^server/#server/g' /etc/ntp.conf

if [[ -z "${NTP_EXTERNAL_SERVER}" ]]; then
  echo ""
else
  ntpdate $NTP_EXTERNAL_SERVER
  echo "server $NTP_EXTERNAL_SERVER iburst" >> /etc/ntp.conf
fi
echo "server 127.127.1.0" >> /etc/ntp.conf
echo "fudge 127.127.1.0 stratum 2" >> /etc/ntp.conf
echo "fudge 127.127.0.1 stratum 2" >> /etc/ntp.conf
systemctl enable ntpd && systemctl start ntpd

echo "---------------------------------------------------"
echo "Disable SELinux"
setenforce 0
sed -i 's/^SELINUX=.*/SELINUX=disabled/g' /etc/selinux/config

echo "---------------------------------------------------"
echo "Set umask=0022"
umask 0022 && echo umask 0022 >> /etc/profile

echo "---------------------------------------------------"
echo "Install & Configure SSSD"
yum install openssl-devel.x86_64 openldap-clients sssd

cat >/etc/sssd/sssd.conf <<EOL
[sssd]
config_file_version = 2
domains = default
services = nss, pam

[nss]
filter_groups = root
filter_users = root
reconnection_retries = 3

[pam]
reconnection_retries = 3
offline_credentials_expiration = 2
offline_failed_login_attempts = 3
offline_failed_login_delay = 5

[domain/default]
auth_provider = ldap
id_provider = ldap
min_id = 2000
ldap_tls_reqcert = never
ldap_uri = ldap://dmmanager:389
ldap_search_base = $LDAP_SEARCH_BASE
cache_credentials = True 
EOL

chmod 600 /etc/sssd/sssd.conf
systemctl enable sssd
systemctl start sssd
authconfig --enablesssd --enablesssdauth --enablelocauthorize --enablemkhomedir --update