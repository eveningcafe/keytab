#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as non-root" 
   exit 1
fi

HdfsPrincipal=`klist -k /etc/security/keytabs/hdfs.headless.keytab | grep "hdfs" | grep "@" | head -n 1| awk '{ print $2 }'`
echo $HdfsPrincipal
kinit -kt /etc/security/keytabs/hdfs.headless.keytab $HdfsPrincipal

OozieLib=`hdfs dfs -ls /user/oozie/share/lib/ | grep "lib_"`
OozieLib=`echo $OozieLib | rev | cut -d' ' -f1 | rev`
echo $OozieLib


mkdir -p /tmp/spark2
cp /usr/hdp/current/spark2-client/jars/*.jar /tmp/spark2
rm -rf /tmp/spark2/aws-java-sdk-core-*
rm -rf /tmp/spark2/aws-java-sdk-kms-*
rm -rf /tmp/spark2/aws-java-sdk-s3-*
rm -rf /tmp/spark2/azure-data-lake-store-sdk-*
rm -rf /tmp/spark2/azure-keyvault-core-*
rm -rf /tmp/spark2/azure-storage-*
rm -rf /tmp/spark2/commons-lang3-*
rm -rf /tmp/spark2/guava-*
rm -rf /tmp/spark2/hadoop-aws-*
rm -rf /tmp/spark2/hadoop-azure-*
rm -rf /tmp/spark2/hadoop-azure-datalake-*
rm -rf /tmp/spark2/jackson-annotations-*
rm -rf /tmp/spark2/jackson-core-*
rm -rf /tmp/spark2/jackson-databind-*
rm -rf /tmp/spark2/joda-time-*
rm -rf /tmp/spark2/json-simple-*
rm -rf /tmp/spark2/okhttp-*
rm -rf /tmp/spark2/okio-*
cp /usr/hdp/current/spark2-client/python/lib/py* /tmp/spark2

hdfs dfs -get $OozieLib/spark/oozie-sharelib-spark-*.jar /tmp/spark2/

hdfs dfs -mkdir $OozieLib/spark2

hdfs dfs -rm $OozieLib/oozie/jackson-*

hdfs dfs -put /tmp/spark2/*.jar $OozieLib/spark2

hdfs dfs -chown -R oozie:hdfs $OozieLib/spark2

hdfs dfs -chmod -R 755 $OozieLib/spark2

rm -rf /tmp/spark2

OoziePrincipal=`klist -k /etc/security/keytabs/oozie.service.keytab | grep "oozie" | grep "@" | head -n 1| awk '{ print $2 }'`
echo $OoziePrincipal
kinit -kt /etc/security/keytabs/oozie.service.keytab $OoziePrincipal

oozie admin -sharelibupdate

oozie admin -shareliblist spark2

echo "---------------------------------------------------"
echo "Done"

