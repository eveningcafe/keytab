#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as non-root" 
   exit 1
fi

#change it
LDAP_ORGANISATION="VCS"
LDAP_DOMAIN="sirc.com"
LDAP_BASE_DN="dc=sirc,dc=com"
LDAP_ADMIN_PASSWORD="password"
AMBARI_DOMAIN="dmmanager"

yum install openssl-devel.x86_64 openldap-clients

echo "---------------------------------------"
echo "Deploy openldap images:"
wget http://dmmanager/docker/repo/openldap.1.1.11.tar.gz

docker load < openldap.1.1.11.tar.gz

rm -rf openldap.1.1.11.tar.gz

echo "---------------------------------------"
echo "Deploy accmgmt images:"
wget http://dmmanager/docker/repo/accmgmt.0.0.1.tar.gz

docker load < accmgmt.0.0.1.tar.gz

rm -rf accmgmt.0.0.1.tar.gz

echo "-----------------------------------------"
echo "Configure docker-compose"
mkdir -p /home/docker/openldap
cd /home/docker/openldap

cat >/home/docker/openldap/docker-compose.yml <<EOL
version: '3'

services:
  openldap:
    image: osixia/openldap:1.1.11
    container_name: openldap
    restart: always
    environment:
      LDAP_TLS: 'true'
      LDAP_TLS_CRT_FILENAME: 'fullchain.pem'
      LDAP_TLS_KEY_FILENAME: 'privkey.pem'
      LDAP_TLS_CA_CRT_FILENAME: 'fullchain.pem'
      LDAP_ORGANISATION: $LDAP_ORGANISATION
      LDAP_DOMAIN: $LDAP_DOMAIN
      LDAP_BASE_DN: $LDAP_BASE_DN
      LDAP_ADMIN_PASSWORD: $LDAP_ADMIN_PASSWORD
      LDAP_TLS_CIPHER_SUITE: "NORMAL"
      LDAP_TLS_VERIFY_CLIENT: "allow"
    volumes:
      - ./database:/var/lib/ldap
      - ./config:/etc/ldap/slapd.d
    ports:
      - "389:389"
      - "639:639"
    logging:
      options:
        max-size: "12m"
        max-file: "5"
      driver: "json-file"
    networks:
      - accmgmt-ldap

  accmgmt:
    image: accmgmt:0.0.1
    restart: always
    environment:
      - LDAP_HOST=openldap
      - LDAP_PORT=389
      - LDAP_BASE_DN=$LDAP_BASE_DN
      - AMBARI_DOMAIN=$AMBARI_DOMAIN
      - AMBARI_PORT=8080
    logging:
      options:
        max-size: "50m"
        max-file: "5"
      driver: "json-file"
    volumes:
      - logsaccmgmt:/app/account_management/logs/
    ports:
      - "9980:8888"
    networks:
      - accmgmt-ldap

networks:
  accmgmt-ldap:
    driver: bridge

volumes:
  logsaccmgmt:
    driver: local
EOL

echo "Start openldap ..."
cd /home/docker/openldap
docker-compose up -d
echo "Waitting 10 seconds ..."
sleep 10
docker logs --tail 10 openldap

cat >/home/docker/openldap/docker-compose.yml <<EOL
version: '3'

services:
  openldap:
    image: osixia/openldap:1.1.11
    container_name: openldap
    restart: always
    environment:
      LDAP_TLS: 'true'
      LDAP_TLS_CRT_FILENAME: 'fullchain.pem'
      LDAP_TLS_KEY_FILENAME: 'privkey.pem'
      LDAP_TLS_CA_CRT_FILENAME: 'fullchain.pem'
      LDAP_ORGANISATION: $LDAP_ORGANISATION
      LDAP_DOMAIN: $LDAP_DOMAIN
      LDAP_BASE_DN: $LDAP_BASE_DN
      LDAP_TLS_CIPHER_SUITE: "NORMAL"
      LDAP_TLS_VERIFY_CLIENT: "allow"
    volumes:
      - ./database:/var/lib/ldap
      - ./config:/etc/ldap/slapd.d
    ports:
      - "389:389"
      - "639:639"
    logging:
      options:
        max-size: "12m"
        max-file: "5"
      driver: "json-file"
    networks:
      - accmgmt-ldap

  accmgmt:
    image: accmgmt:0.0.1
    restart: always
    environment:
      - LDAP_HOST=openldap
      - LDAP_PORT=389
      - LDAP_BASE_DN=$LDAP_BASE_DN
      - AMBARI_DOMAIN=$AMBARI_DOMAIN
      - AMBARI_PORT=8080
    logging:
      options:
        max-size: "50m"
        max-file: "5"
      driver: "json-file"
    volumes:
      - logsaccmgmt:/app/account_management/logs/
    ports:
      - "9980:8888"
    networks:
      - accmgmt-ldap

networks:
  accmgmt-ldap:
    driver: bridge

volumes:
  logsaccmgmt:
    driver: local
EOL

docker-compose restart

echo "Waitting 3 seconds ..."
sleep 3
echo "Install openldap client"
yum install openldap-clients

echo "Config acl"
cat >/home/docker/openldap/config/acl.ldif <<EOL
dn: olcDatabase={1}hdb,cn=config
changetype: modify
delete: olcAccess
-
add: olcAccess
olcAccess: to attrs=userPassword,shadowLastChange by self write by dn="cn=admin,$LDAP_BASE_DN" write by anonymous auth by * none
olcAccess: to * by self write by dn="cn=admin,$LDAP_BASE_DN" write by * read
EOL
docker exec -it openldap ldapmodify -Y EXTERNAL -H ldapi:/// -f /etc/ldap/slapd.d/acl.ldif
rm -rf /home/docker/openldap/config/acl.ldif

echo "Delete admin user (https://github.com/osixia/docker-openldap/issues/161). Please enter LDAP admin password."
ldapdelete -h dmmanager -D cn=admin,$LDAP_BASE_DN -W cn=admin,$LDAP_BASE_DN

echo "Create OU: Groups, Users, Policies"
cat >/tmp/newgroups.ldif <<EOL
dn: ou=Groups,$LDAP_BASE_DN
objectClass: top
objectClass: organizationalUnit
ou: Groups

dn: ou=Users,$LDAP_BASE_DN
objectClass: top
objectClass: organizationalUnit
ou: Users

dn: ou=Policies,$LDAP_BASE_DN
objectClass: top
objectClass: organizationalUnit
ou: Policies
EOL
ldapadd -h dmmanager -D cn=admin,$LDAP_BASE_DN -W -f /tmp/newgroups.ldif
rm -rf /tmp/newgroups.ldif

echo "Config password policy"
cat >/home/docker/openldap/config/ppmodule_overlay.ldif <<EOL
dn: cn=module{0},cn=config
changetype: modify
add: olcModuleLoad
olcModuleLoad: ppolicy

dn: olcOverlay={0}ppolicy,olcDatabase={1}hdb,cn=config
objectClass: olcOverlayConfig
objectClass: olcPPolicyConfig
olcOverlay: {0}ppolicy
olcPPolicyDefault: cn=default,ou=Policies,$LDAP_BASE_DN
EOL
docker exec -it openldap ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/ldap/slapd.d/ppmodule_overlay.ldif
rm -rf /home/docker/openldap/config/ppmodule_overlay.ldif
sleep 3
cat >/tmp/defaultpolicy.ldif <<EOL
dn: cn=default,ou=Policies,$LDAP_BASE_DN
cn: default
sn: default
objectClass: pwdPolicy
objectClass: person
objectClass: top
pwdAllowUserChange: TRUE
pwdAttribute: userPassword
pwdCheckQuality: 2
pwdExpireWarning: 600
pwdFailureCountInterval: 30
pwdGraceAuthNLimit: 5
pwdInHistory: 5
pwdLockout: TRUE
pwdLockoutDuration: 30
pwdMaxAge: 0
pwdMaxFailure: 5
pwdMinAge: 0
pwdMinLength: 8
pwdMustChange: FALSE
pwdSafeModify: FALSE
EOL
ldapadd -h dmmanager -D cn=admin,$LDAP_BASE_DN -W -f /tmp/defaultpolicy.ldif
rm -rf /tmp/defaultpolicy.ldif



