#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as non-root" 
   exit 1
fi

#change it
POSTGRES_PASSWORD=password
POSTGRES_AMBARI_PASSWORD=password
POSTGRES_OOZIE_PASSWORD=password
POSTGRES_HIVE_PASSWORD=password

echo "---------------------------------------"
echo "Deploy postgres images:"
wget http://dmmanager/docker/repo/postgres.10.1.tar.gz

docker load < postgres.10.1.tar.gz

rm -rf postgres.10.1.tar.gz

echo "-----------------------------------------"
echo "Configure docker-compose"
mkdir -p /home/docker/postgres
cd /home/docker/postgres

cat >/home/docker/postgres/docker-compose.yml <<EOL
version: '3'

services: 
  postgres: 
    image: postgres:10.1
    container_name: postgredb
    restart: always
    volumes:
      - ./data:/var/lib/postgresql/data
    ports: 
      - "5432:5432"
    logging:
      options:
        max-size: "12m"
        max-file: "5"
      driver: "json-file"
    environment: 
      - POSTGRES_PASSWORD=$POSTGRES_PASSWORD
EOL

echo "Start postgres ..."
cd /home/docker/postgres
docker-compose up -d
echo "Waitting 10 seconds ..."
sleep 10
docker logs --tail 10 postgredb

cat >/home/docker/postgres/docker-compose.yml <<EOL
version: '3'

services: 
  postgres: 
    image: postgres:10.1
    container_name: postgredb
    restart: always
    volumes:
      - ./data:/var/lib/postgresql/data
    ports: 
      - "5432:5432"
    logging:
      options:
        max-size: "12m"
        max-file: "5"
      driver: "json-file"
EOL

docker-compose restart

echo "Waitting 3 seconds ..."
sleep 3
echo "Install postgresql client"
yum install postgresql

echo "-----------------------------------------------"
echo "Create ambari, oozie account"
echo "CREATE DATABASE ambari; CREATE USER ambari WITH PASSWORD '$POSTGRES_AMBARI_PASSWORD'; GRANT ALL PRIVILEGES ON DATABASE ambari TO ambari; CREATE DATABASE oozie; CREATE USER oozie WITH PASSWORD '$POSTGRES_OOZIE_PASSWORD'; GRANT ALL PRIVILEGES ON DATABASE oozie TO oozie;CREATE DATABASE hive; CREATE USER hive WITH PASSWORD '$POSTGRES_HIVE_PASSWORD'; GRANT ALL PRIVILEGES ON DATABASE hive TO hive;" | psql -h dmmanager -U postgres




