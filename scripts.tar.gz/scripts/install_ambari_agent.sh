#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as non-root" 
   exit 1
fi

wget -nv http://dmmanager/ambari/centos7/2.x/updates/2.6.1.0/ambari.repo -O /etc/yum.repos.d/ambari.repo
yum update
yum install ambari-agent

sed -i 's/hostname=localhost/hostname=dmmanager/g' /etc/ambari-agent/conf/ambari-agent.ini

ambari-agent start