#!/bin/bash

#Change it
REALM="SIRC.COM"

if [ -z "$1" ]
then
    echo "Using: `basename $0` user group"
    exit 1
fi

if [ -z "$2" ]
then
    echo "Using: `basename $0` user group"
    exit 1
fi

USER=$1
GROUP=$2

echo $USER:$GROUP

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as non-root" 
   exit 1
fi

echo "------------------------------------------"
echo "Create home directory"
su -c 'ls -l /home/$USER; whoami; exit' $USER
sleep 1


echo "-----------------------------------------"
echo "Create keytab"

k1="kadmin -p admin/admin@$REALM -q 'add_principal -randkey $USER@$REALM'"
echo $k1
eval $k1
sleep 1

k2="kadmin -p admin/admin@$REALM -q 'xst -k /root/$USER.keytab $USER@$REALM'"
echo $k2
eval $k2
sleep 1

mv /root/$USER.keytab /home/$USER
chown $USER:root /home/$USER/$USER.keytab

echo "-----------------------------------------"
echo "Create HDFS user directory"
HdfsPrincipal=`klist -k /etc/security/keytabs/hdfs.headless.keytab | grep "hdfs" | grep "@" | head -n 1| awk '{ print $2 }'`
echo $HdfsPrincipal
kinit -kt /etc/security/keytabs/hdfs.headless.keytab $HdfsPrincipal

hdfs dfs -mkdir /user/$USER
hdfs dfs -chown $USER:$GROUP /user/$USER
