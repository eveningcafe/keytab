#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as non-root" 
   exit 1
fi

#change it
REALM=SIRC.COM

yum install krb5-server krb5-libs krb5-workstation

REALM_UPPERCASE=${REALM^^}
REALM_LOWERCASE=${REALM,,}

cat >/etc/krb5.conf <<EOL
includedir /etc/krb5.conf.d/

[logging]
 default = FILE:/var/log/krb5libs.log
 kdc = FILE:/var/log/krb5kdc.log
 admin_server = FILE:/var/log/kadmind.log

[libdefaults]
 dns_lookup_realm = false
 ticket_lifetime = 24h
 renew_lifetime = 7d
 forwardable = true
 rdns = false
 default_realm = $REALM_UPPERCASE
 default_ccache_name = KEYRING:persistent:%{uid}

[realms]
 $REALM_UPPERCASE = {
  kdc = dmmanager
  admin_server = dmmanager
 }

[domain_realm]
 .$REALM_LOWERCASE = $REALM_UPPERCASE
 $REALM_LOWERCASE = $REALM_UPPERCASE
EOL

echo "*/admin@$REALM_UPPERCASE	*" > /var/kerberos/krb5kdc/kadm5.acl

kdb5_util create -s
systemctl start krb5kdc
systemctl start kadmin
kadmin.local -q "addprinc admin/admin"
systemctl restart kadmin
systemctl enable krb5kdc
systemctl enable kadmin

