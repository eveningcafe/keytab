#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as non-root" 
   exit 1
fi

currentdir=`pwd`

echo "---------------------------------------------------"
echo "Disable firewalld:"
systemctl disable firewalld && service firewalld stop

echo "---------------------------------------------------"
echo "Install docker:"
rpm -Uvh $currentdir/docker/*.rpm

echo "---------------------------------------------------"
echo "Start docker:"
systemctl enable docker
systemctl start docker

echo "---------------------------------------------------"
echo "Install docker-compose:"
cp $currentdir/docker/docker-compose-Linux-x86_64 /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
docker-compose --version

echo "---------------------------------------------------"
echo "Deploy nginx images:"
docker load < $currentdir/nginx.1.13.8.tar.gz

echo "-----------------------------------------"
echo "Configure docker-compose"
mkdir -p /home/docker/repo
cd /home/docker/repo

cat >/home/docker/repo/docker-compose.yml <<EOL
version: '3'

services:
  nginx:
    image: nginx:1.13.8
    restart: always
    volumes:
      - ./repo:/usr/share/nginx/html:ro
    ports:
      - "80:80"
    logging:
      options:
        max-size: "12m"
        max-file: "5"
      driver: "json-file"
EOL

echo "Start repo ..."
cd /home/docker/repo
docker-compose up -d
echo "Waitting 10 seconds ..."
sleep 10

echo "-----------------------------------------"
echo "Configure repos"
listOfRepos="centos7_os.tar.gz ambari.tar.gz ARTIFACTS.tar.gz docker.tar.gz HDP.tar.gz HDP-GPL.tar.gz HDP-UTILS-1.1.0.22.tar.gz scripts.tar.gz"
for repoCompress in $listOfRepos  
do
  mv $currentdir/repo/$repoCompress /home/docker/repo/repo
  cd /home/docker/repo/repo
  tar -xvf /home/docker/repo/repo/$repoCompress
  rm -rf /home/docker/repo/repo/$repoCompress 
done
chown -R root:root /home/docker/repo/repo

echo "---------------------------------------------------"
echo "Backup yum.repo"
mkdir -p /root/yum.repo.bak
mv /etc/yum.repos.d/CentOS-*.repo /root/yum.repo.bak

echo "---------------------------------------------------"
echo "Setup Centos internal repository"
wget -nv http://dmmanager/centos7_os/CentOS-OS-Internal.repo -O /etc/yum.repos.d/CentOS-OS-Internal.repo
yum update
rm -rf /etc/yum.repos.d/CentOS-Base.repo 
rm -rf /etc/yum.repos.d/CentOS-CR.repo 
rm -rf /etc/yum.repos.d/CentOS-Debuginfo.repo 
rm -rf /etc/yum.repos.d/CentOS-fasttrack.repo 
rm -rf /etc/yum.repos.d/CentOS-Media.repo 
rm -rf /etc/yum.repos.d/CentOS-Sources.repo 
rm -rf /etc/yum.repos.d/CentOS-Vault.repo
yum update
