#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as non-root" 
   exit 1
fi

echo "---------------------------------------------------"
echo "Create ui topology"
cat >/usr/hdp/current/knox-server/conf/topologies/ui.xml <<EOL
<topology>
    <gateway>
        <provider>
            <role>authentication</role>
            <name>Anonymous</name>
            <enabled>true</enabled>
        </provider>
        <provider>
            <role>identity-assertion</role>
            <name>Default</name>
            <enabled>false</enabled>
        </provider>
    </gateway>
    <service>
        <role>AMBARI</role>
        <url>http://dmmanager:8080</url>
    </service>

    <service>
        <role>AMBARIUI</role>
        <url>http://dmmanager:8080</url>
    </service>

    <service>
        <role>RANGER</role>
        <url>http://dmmanager:6080</url>
    </service>

    <service>
        <role>RANGERUI</role>
        <url>http://dmmanager:6080</url>
    </service>

    <service>
        <role>ACCMGMT</role>
        <url>http://dmmanager:9980</url>
    </service>

    <service>
        <role>ZEPPELINUI</role>
        <url>http://dmmanager:9995</url>
    </service>

    <service>
        <role>ZEPPELINWS</role>
        <url>ws://dmmanager:9995/ws</url>
    </service>

    <service>
        <role>SPARKHISTORYUI</role>
        <url>http://dmmaster:18081</url>
    </service>

    <service>
	      <role>GUIDES</role>
        <url>http://dmmanager:9981</url>
    </service>
</topology> 
EOL
chown knox:knox /usr/hdp/current/knox-server/conf/topologies/ui.xml

echo "---------------------------------------------------"
echo "Config knox services"
wget http://dmmanager/ARTIFACTS/services.tar.gz
mv /usr/hdp/current/knox-server/data/services ~/services_knox_bak
tar -xvf services.tar.gz -C /usr/hdp/current/knox-server/data/
chown -R knox:knox /usr/hdp/current/knox-server/data/services
chmod -R 751 /usr/hdp/current/knox-server/data/services

